import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./Home";
import Model1 from "./Models/Model1";
import Model2 from "./Models/Model2";
import Model3 from "./Models/Model3";
import Model4 from "./Models/Model4";
import Model5 from "./Models/Model5";
// import About from "./components/About";
// import Contact from "./components/Contact";

const App = () => {
  return (
    <Router>
      <div>
        <Routes>
          <Route exact path="/" element={<Home />} />
          <Route path="/models/model1" element={<Model1 />} />
          <Route path="/models/model2" element={<Model2 />} />
          <Route path="/models/model3" element={<Model3 />} />
          <Route path="/models/model4" element={<Model4 />} />
          <Route path="/models/model5" element={<Model5 />} />
          {/* <Route path="/contact" element={<Contact />} /> */}
        </Routes>
      </div>
    </Router>
  );
};

export default App;
