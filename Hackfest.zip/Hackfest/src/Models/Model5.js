import React from "react";

const Model5 = () => {
  return (
    <div>
      <h5>Model5</h5>
    </div>
  );
};

export default Model5;
