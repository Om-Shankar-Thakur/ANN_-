import React from "react";

const Model2 = () => {
  return (
    <div>
      <h5>Model2</h5>
    </div>
  );
};

export default Model2;
