import React from "react";

const Model3 = () => {
  return (
    <div>
      <h5>Model3</h5>
    </div>
  );
};

export default Model3;
