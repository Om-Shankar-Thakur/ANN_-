import React from "react";

const Model1 = () => {
  return (
    <div>
      <h5>Model1</h5>
    </div>
  );
};

export default Model1;
