import React from "react";

const Model4 = () => {
  return (
    <div>
      <h5>Model4</h5>
    </div>
  );
};

export default Model4;
