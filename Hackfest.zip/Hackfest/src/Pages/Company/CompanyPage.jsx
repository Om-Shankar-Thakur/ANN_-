import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import "./companyPage.css";
import companyData from "../../data/company.json";
import PracticeBar from "../../Navbar/PracticeBar";
import Footer from "../../../Footer/Footer";

const CompanyPage = () => {
  const { id } = useParams();
  const [company, setCompany] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchCompany = () => {
      const companyDataItem = companyData.find((item) => item.id === id);
      if (companyDataItem) {
        setCompany(companyDataItem);
      } else {
        setError("Company not found");
      }
    };

    fetchCompany();
  }, [id]);

  if (error) {
    return <div>{error}</div>;
  }

  if (!company) {
    return <div>Loading...</div>;
  }

  return (
    <>
      <PracticeBar />
      <div className="setBack">
        <div className="head_part">
          <div className="logoImage">
            <img src={company.logo} alt={company.title} />
          </div>
          <div className="compInfo">
            <b>{company.title}</b>
            <p>{company.subtitle}</p>
            <div className="compNature">
              {company.nature.map((nature, index) => (
                <div className="compNature_div" key={index}>
                  {nature}
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="overview">
          <div className="left_one">
            <div className="moreInfo">
              <b>Overview</b>
              <p>{company.about}</p>
            </div>
          </div>
        </div>
      </div>
      <div className="footer-container">
        <Footer />
      </div>
    </>
  );
};

export default CompanyPage;
