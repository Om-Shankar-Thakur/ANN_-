import React, { useEffect } from "react";
import "./Company.css";
import { IoIosStar } from "react-icons/io";
import { Link } from "react-router-dom";

const Company = () => {
  useEffect(() => {}, []);

  return (
    <div className="container">
      <div className="topHire">
        <h2>AI for Sustainable Agriculture</h2>
      </div>
      <div className="company_main">
        <div className="comp_showlist">
          <div className="companies_list">
            <Link
              to={`/models/model1`}
              className="company_card"
              style={{ textDecoration: "none" }}
            >
              <img
                className="logo_image"
                src="https://media.licdn.com/dms/image/C5612AQHvdSEgNkEd9Q/article-cover_image-shrink_600_2000/0/1634099172188?e=2147483647&v=beta&t=5R87hZJO9459uAI_xoToV0Q3_zkVrGMItcRk383Vveg"
                alt="Crop Monitoring and Management"
              />
              <div className="company_info">
                <p style={{ textAlign: "center" }}>
                  Crop Monitoring and Management
                </p>
              </div>
            </Link>
            <div className="align-right">
              <Link
                to={`/models/model2`}
                className="company_card"
                style={{ textDecoration: "none" }}
              >
                <div className="company_info">
                  <p style={{ textAlign: "center" }}>Precision Agriculture</p>
                </div>
                <img
                  className="logo_image"
                  src="https://static.vecteezy.com/system/resources/previews/020/465/922/non_2x/woman-hand-with-potato-plantations-grow-in-field-vegetable-rows-farming-agriculture-smart-farming-and-precision-agriculture-4-0-modern-agricultural-technology-and-data-management-to-industry-farm-photo.jpg"
                  alt="Precision Agriculture"
                />
              </Link>
            </div>
            <Link
              to={`/models/model3`}
              className="company_card"
              style={{ textDecoration: "none" }}
            >
              <img
                className="logo_image"
                src="https://www.asiafarming.com/wp-content/uploads/2023/03/Different-Ways-to-Improve-Crop-Yield1-1024x678.jpg"
                alt="Crop Yield Prediction"
              />
              <div className="company_info">
                <p style={{ textAlign: "center" }}>Crop Yield Prediction</p>
              </div>
            </Link>
            <div className="align-right">
              <Link
                to={`/models/model4`}
                className="company_card"
                style={{ textDecoration: "none" }}
              >
                <div className="company_info">
                  <p style={{ textAlign: "center" }}>Climate Resilience</p>
                </div>
                <img
                  className="logo_image"
                  src="https://img.freepik.com/free-photo/climate-change-with-dry-soil_23-2149217819.jpg"
                  alt="Climate Resilience"
                />
              </Link>
            </div>
            <Link
              to={`/models/model5`}
              className="company_card"
              style={{ textDecoration: "none" }}
            >
              <img
                className="logo_image"
                src="https://www.course5i.com/wp-content/uploads/Advt_WP_thumbnails.jpg"
                alt="Market Intelligence"
              />
              <div className="company_info">
                <p style={{ textAlign: "center" }}>Market Intelligence</p>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Company;
