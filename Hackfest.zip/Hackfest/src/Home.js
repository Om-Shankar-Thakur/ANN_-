import React from "react";
// import a from "./Images/a.jpeg";
import Company from "./Pages/Company/Company";

const Home = () => {
  return (
    <div>
      <Company />
    </div>
  );
};

export default Home;
