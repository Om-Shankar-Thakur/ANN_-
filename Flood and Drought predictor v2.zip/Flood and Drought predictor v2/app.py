import streamlit as st
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import ElasticNet
import pickle

# Define the plot_graphs function
def plot_graphs(y_true, y_pred, title):
    plt.figure(figsize=(12, 6))
    sns.scatterplot(x=y_true, y=y_pred, alpha=0.5)
    sns.regplot(x=y_true, y=y_pred, scatter=False, color='r')
    plt.xlabel('True Values')
    plt.ylabel('Predicted Values')
    plt.title(title)
    return plt

# Define a dictionary that maps state names to file names
state_file_dict = {
    'JHARKHAND': 'JHARKHAND',
    'ORISSA': 'ORISSA',
    # Add more states as needed
}

# Load data based on the user's state selection
state = st.sidebar.selectbox("Select State", list(state_file_dict.keys()))
fn = state_file_dict[state]
data = pd.read_csv(f'Data/{fn}.csv')

# Convert 'YEAR' column to numeric type
data['YEAR'] = pd.to_numeric(data['YEAR'])

# Exclude 'SUBDIVISION' and 'YEAR' columns
X_cols = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC']
y_col = 'DEC'
X = data[X_cols]
y = data[y_col]

# Handle missing values
X.fillna(X.mean(), inplace=True)
y.fillna(y.mean(), inplace=True)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.01, random_state=42)

# Define and train the model
def train_model(X_train, y_train, alpha=0.5):
    reg = ElasticNet(alpha=alpha)
    reg.fit(X_train, y_train)
    return reg

reg = train_model(X_train, y_train)

# Test the model on a selected year
test_year = st.sidebar.slider("Select Year", min_value=1901, max_value=2100, value=2015)
temp = data[data['YEAR'] == test_year]
X_year = temp[X_cols]
y_year = temp[y_col]
y_year_pred = reg.predict(X_year)

# Display mean and standard deviation
st.write(f"Mean {test_year}: {np.mean(y_year)} ({np.mean(y_year_pred)})")
st.write(f"Standard deviation {test_year}: {np.sqrt(np.var(y_year))} ({np.sqrt(np.var(y_year_pred))})")

# Plot for the year
fig = plot_graphs(y_year, y_year_pred, f"Year-{test_year}")
st.pyplot(fig)

# Calculate total rainfall and classify the state for the selected year
total_rainfall = np.sum(y_year_pred)
avg_rainfall = np.mean(y_year_pred)
classification = 'Drought State'  # Placeholder classification

if total_rainfall > 1000:
    classification = 'Floody State'
elif avg_rainfall > 50:
    classification = 'Wet State'
elif avg_rainfall > 25:
    classification = 'Dry State'

st.write(f"Total Rainfall: {total_rainfall:.2f} mm")
st.write(f"Average Rainfall: {avg_rainfall:.2f} mm")
st.write(f"Classification: {classification}")

# Save the model
Pkl_Filename = f"trained/{fn}.pkl"
with open(Pkl_Filename, 'wb') as file:
    pickle.dump(reg, file)
